# SaaS MX Starter

Next.js 14 + Stripe + Auth. **Con facturación mexicana resuelta.**

Esto no es "copia y pega". Es "copia y pega y ya sabes cuánto te queda
después de IVA y retenciones".

---

## Qué incluye

| | |
|---|---|
| Next.js 14 (App Router) | estructura lista, no un tutorial |
| Auth con JWT + bcrypt | registro, login, sesión, rutas protegidas |
| Stripe Checkout + webhooks | verificados con `constructEvent` |
| Prisma + PostgreSQL | schema con User y Subscription |
| Portal de cliente | lista sus pagos y su estado |
| Tailwind | landing que convierte, no boilerplate bonito |
| Emails transaccionales | vía Resend, plantillas incluidas |
| **Cálculo fiscal México** | IVA 16%, ISR 1.15%, honorarios 8.33% |
| **Facturación CFDI-ready** | estructura para timbrar con un PAC |

---

## Lo que casi nadie incluye: el-money-real en México

La mayoría de boilerplates asumen que cobras lo que dice tu precio.
En México no es así. Este starter trae `src/lib/mexico.ts`:

```ts
import { netoMexico } from '@/lib/mexico'

// Lo que pides vs lo que te queda
const resultado = netoMexico({
  precio: 10_000,
  esPersonaFisica: true
})
// { subtotal, iva, retencionIsr, retencionHonorarios, neto, margen }
```

```ts
// Para cuando pidas un precio y no quieras adivinar
precioParaRecibir(9_000, { esPersonaFisica: true })  // 10_000
```

Sin esto, el primer mes cobras de menos y no sabes por qué.

---

## Puesta en marcha

```bash
npm install
cp .env.example .env.local     # rellena tus claves
npm run db:push
npm run dev
```

### Variables de entorno
```
DATABASE_URL=postgresql://usuario:pass@localhost:5432/saas
JWT_SECRET=          # genera uno: openssl rand -base64 32
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_APP_URL=http://localhost:3000
RESEND_API_KEY=re_...
```

### Webhook de Stripe en local
```bash
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

---

## Requisitos

- Node 18+ (probado en 20)
- Una cuenta de Stripe (test mode basta para empezar)
- Para deploy: Vercel, Railway o Render

---

## Licencia

Uso comercial para **un** producto. Si quieres reusarlo para varios
productos, compra la licencia extendida.

Este starter no incluye la clave de tu cuenta de Stripe ni la de tu
proveedor de facturación. Es tuyo desde el primer minuto.
