/**
 * Calculo fiscal para freelancers y PYMEs en Mexico.
 *
 * Las tasas son de 2026. Cámbialas en un solo lugar cuando el SAT
 * actualice — no las disperses por el código.
 *
 * NO ES ASESORIA FISCAL. Para tu caso especifico, consulta a un contador.
 */

export const TASAS = {
  /** IVA general */
  iva: 0.16,
  /** Tasa unificada ISR provisional (retenido por personas morales) */
  isrProvisional: 0.0115,
  /**
   * Retencion de IVA por honorarios a personas fisicas.
   * 33.5% de retencion, pero solo se entrega al fisco el 8.33%
   * (el resto es compensacion de ISR). Efectivo: 8.33%.
   */
  retencionHonorarios: 0.0833,
} as const

export interface EntradaMexico {
  /** Precio antes de impuestos */
  precio: number
  /** Si el cliente es persona fisica (retiene honorarios) */
  esPersonaFisica?: boolean
  /** Gastos deducibles, para el margen */
  gastos?: number
}

export interface ResultadoMexico {
  subtotal: number
  /** IVA que se le cobra al cliente */
  iva: number
  /** Total que paga el cliente */
  total: number
  retencionIsr: number
  retencionHonorarios: number
  /** Lo que de verdad llega a tu cuenta */
  neto: number
  /** Margen sobre el subtotal, o null si no hay datos */
  margen: number | null
}

export function netoMexico(e: EntradaMexico): ResultadoMexico {
  const subtotal = e.precio
  const iva = subtotal * TASAS.iva
  const retencionIsr = subtotal * TASAS.isrProvisional
  const retencionHonorarios = e.esPersonaFisica
    ? subtotal * TASAS.retencionHonorarios
    : 0

  const neto = subtotal - retencionIsr - retencionHonorarios
  // subtotal puede ser 0 (precio sin definir). Sin este guarda, la app
  // revienta con NaN en vez de mostrar 0.
  const margen =
    e.gastos != null && subtotal !== 0 ? (subtotal - e.gastos) / subtotal : null

  return {
    subtotal: r2(subtotal),
    iva: r2(iva),
    total: r2(subtotal + iva),
    retencionIsr: r2(retencionIsr),
    retencionHonorarios: r2(retencionHonorarios),
    neto: r2(neto),
    margen,
  }
}

/**
 * Que precio tienes que poner para recibir `objetivo` en la cuenta.
 * Invierte netoMexico para ti.
 */
export function precioParaRecibir(
  objetivo: number,
  opts: { esPersonaFisica?: boolean } = {}
): number {
  const retencion =
    TASAS.isrProvisional +
    (opts.esPersonaFisica ? TASAS.retencionHonorarios : 0)
  // objetivo 0 devolveria Infinity; el caller espera un numero usable.
  if (objetivo <= 0) return 0
  return r2(objetivo / (1 - retencion))
}

const r2 = (n: number) => Math.round(n * 100) / 100
