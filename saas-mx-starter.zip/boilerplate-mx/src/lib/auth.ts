import 'server-only'
import { cookies } from 'next/headers'
import { SignJWT, jwtVerify } from 'jose'
import bcrypt from 'bcryptjs'

const secret = new TextEncoder().encode(process.env.JWT_SECRET!)

export async function hashPassword(pw: string) {
  return bcrypt.hash(pw, 12)
}

export async function verifyPassword(pw: string, hash: string) {
  return bcrypt.compare(pw, hash)
}

export async function crearToken(userId: string) {
  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret)
}

export async function verificarToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, secret)
    return payload.sub as string
  } catch {
    return null
  }
}

export async function sesionActual() {
  const token = cookies().get('token')?.value
  if (!token) return null
  return verificarToken(token)
}
