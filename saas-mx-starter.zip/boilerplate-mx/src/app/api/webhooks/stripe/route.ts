import { headers } from 'next/headers'
import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(req: Request) {
  const body = await req.text()
  const sig = headers().get('stripe-signature')!

  let event: Stripe.Event
  try {
    // constructEvent valida la firma. Nunca parsees sin verificar.
    event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err) {
    console.error('Firma invalida:', err)
    return new Response('Firma invalida', { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session
    const userId = session.metadata?.userId
    if (!userId) {
      console.error('Sesion sin userId en metadata:', session.id)
      return new Response('ok')
    }

    // Guarda el desglose fiscal junto al pago: el dia que necesites
    // facturar, ya tienes los numeros sin recalcular nada.
    const { precio, esPersonaFisica } = JSON.parse(
      session.metadata?.desglose ?? '{}'
    )
    const f = netoMexico({ precio, esPersonaFisica })

    await prisma.pago.create({
      data: {
        usuarioId: userId,
        stripePaymentId: session.payment_intent as string,
        monto: session.amount_total ?? 0,
        moneda: session.currency ?? 'mxn',
        subtotal: f.subtotal,
        iva: f.iva,
        retencionIsr: f.retencionIsr,
        retencionHonorarios: f.retencionHonorarios,
        neto: f.neto,
      },
    })
  }

  return new Response('ok')
}
