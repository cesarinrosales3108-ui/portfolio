'use client'
import { useState } from 'react'
import { netoMexico, precioParaRecibir, TASAS } from '@/lib/mexico'

export default function CalculadoraPrecio() {
  const [objetivo, setObjetivo] = useState(9000)
  const [fisica, setFisica] = useState(true)
  const [gastos, setGastos] = useState(0)

  const precio = precioParaRecibir(objetivo, { esPersonaFisica: fisica })
  const f = netoMexico({ precio, esPersonaFisica: fisica, gastos })

  return (
    <main style={{ maxWidth: 640, margin: '0 auto', padding: 24 }}>
      <h1>¿Qué precio pongo?</h1>

      <label>
       Quiero recibir: ${objetivo.toLocaleString('es-MX')}
        <input type="range" min={1000} max={50000} step={500}
               value={objetivo} onChange={e => setObjetivo(+e.target.value)} />
      </label>

      <label>
        <input type="checkbox" checked={fisica}
               onChange={e => setFisica(e.target.checked)} />
        Mi cliente es persona fisica (me retiene honorarios)
      </label>

      <label>
        Gastos deducibles: ${gastos.toLocaleString('es-MX')}
        <input type="number" value={gastos} onChange={e => setGastos(+e.target.value)} />
      </label>

      <hr />

      <h2>Tienes que cobrar: ${precio.toLocaleString('es-MX')}</h2>
      <table>
        <tbody>
          <tr><td>Subtotal</td><td>${f.subtotal.toLocaleString('es-MX')}</td></tr>
          <tr><td>IVA que se le cobra (16%)</td><td>${f.iva.toLocaleString('es-MX')}</td></tr>
          <tr><td>Total que paga el cliente</td><td><b>${f.total.toLocaleString('es-MX')}</b></td></tr>
          <tr><td>Retencion ISR (1.15%)</td><td>-${f.retencionIsr.toLocaleString('es-MX')}</td></tr>
          <tr><td>Retencion honorarios (8.33%)</td><td>-${f.retencionHonorarios.toLocaleString('es-MX')}</td></tr>
          <tr><td><b>Recibes</b></td><td><b>${f.neto.toLocaleString('es-MX')}</b></td></tr>
          {f.margen != null && (
            <tr><td>Margen</td><td>{(f.margen * 100).toFixed(1)}%</td></tr>
          )}
        </tbody>
      </table>

      <p style={{ fontSize: 13, opacity: .7 }}>
        Tasas 2026: IVA {TASAS.iva * 100}%, ISR {TASAS.isrProvisional * 100}%,
        honorarios {TASAS.retencionHonorarios * 100}%. No es asesoria fiscal.
      </p>
    </main>
  )
}
