import { NextResponse, type NextRequest } from 'next/server'
import { verificarToken } from '@/lib/auth'

const PROTEGIDAS = ['/panel', '/api/pagos']

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  if (!PROTEGIDAS.some(p => pathname.startsWith(p))) return NextResponse.next()

  const token = req.cookies.get('token')?.value
  const userId = token ? await verificarToken(token) : null
  if (!userId) {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    url.searchParams.set('next', pathname)
    return NextResponse.redirect(url)
  }
  return NextResponse.next()
}

export const config = { matcher: ['/panel/:path*', '/api/pagos/:path*'] }
